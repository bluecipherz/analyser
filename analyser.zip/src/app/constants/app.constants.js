/**
 * Created by Rinas Musthafa on 2/11/2017.
 */
export class appConstants{
    constructor() {

        return {
            GROUP: 'in.intellicar.assets.group',
            VEHICLE: 'in.intellicar.assets.vehicle',
            USER: 'in.intellicar.assets.user',
            LOCALUSER: 'in.intellicar.assets.user.localuser',
            ROLE: 'in.intellicar.assets.role',
            DEVICE: 'in.intellicar.assets.device',
            INFO: 'in.intellicar.assets.group',
            PROFILE: 'in.intellicar.assets.profile',
            SIMCARD: 'in.intellicar.assets.simcards',
            ROOT_GROUP:'/2/6/'
        }
    }
}