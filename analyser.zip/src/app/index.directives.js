/**
 * Created by Rinas Musthafa on 2/8/2017.
 */
/* global malarkey:false, moment:false */

//
// angular.module('management')