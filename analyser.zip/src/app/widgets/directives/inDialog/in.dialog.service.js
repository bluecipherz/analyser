/**
 * Created by Rinas Musthafa on 2/11/2017.
 */
export class $inDialog{
    constructor(){
        'ngInject'


    }
}